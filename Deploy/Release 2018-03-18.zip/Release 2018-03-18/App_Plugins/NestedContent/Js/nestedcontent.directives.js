﻿angular.module("umbraco.directives").directive('nestedContentEditor', [

    function () {

        var link = function ($scope) {

            // Clone the model because some property editors
            // do weird things like updating and config values
            // so we want to ensure we start from a fresh every
            // time, we'll just sync the value back when we need to
            $scope.model = angular.copy($scope.ngModel);
            $scope.nodeContext = $scope.model;

            // Find the selected tab
            var selectedTab = $scope.model.tabs[0];

            if ($scope.tabAlias) {
                angular.forEach($scope.model.tabs, function (tab) {
                    if (tab.alias.toLowerCase() == $scope.tabAlias.toLowerCase()) {
                        selectedTab = tab;
                        return;
                    }
                });
            }

            $scope.tab = selectedTab;

            // Listen for sync request
            var unsubscribe = $scope.$on("ncSyncVal", function (ev, args) {
                if (args.id === $scope.model.id) {

                    // Tell inner controls we are submitting
                    $scope.$broadcast("formSubmitting", { scope: $scope });

                    // Sync the values back
                    angular.forEach($scope.ngModel.tabs, function (tab) {
                        if (tab.alias.toLowerCase() == selectedTab.alias.toLowerCase()) {

                            var localPropsMap = selectedTab.properties.reduce(function (map, obj) {
                                map[obj.alias] = obj;
                                return map;
                            }, {});

                            angular.forEach(tab.properties, function (prop) {
                                if (localPropsMap.hasOwnProperty(prop.alias)) {
                                    prop.value = localPropsMap[prop.alias].value;
                                }
                            });

                        }
                    });
                }
            });

            $scope.$on('$destroy', function () {
                unsubscribe();
            });
        }

        return {
            restrict: "E",
            replace: true,
            templateUrl: Umbraco.Sys.ServerVariables.umbracoSettings.appPluginsPath + "/NestedContent/Views/nestedcontent.editor.html",
            scope: {
                ngModel: '=',
                tabAlias: '='
            },
            link: link
        };

    }
]);

//angular.module("umbraco.directives").directive('nestedContentSubmitWatcher', function () {
//    var link = function (scope) {
//        // call the load callback on scope to obtain the ID of this submit watcher
//        var id = scope.loadCallback();
//        scope.$on("formSubmitting", function (ev, args) {
//            // on the "formSubmitting" event, call the submit callback on scope to notify the nestedContent controller to do it's magic
//            if (id === scope.activeSubmitWatcher) {
//                scope.submitCallback();
//            }
//        });
//    }

//    return {
//        restrict: "E",
//        replace: true,
//        template: "",
//        scope: {
//            loadCallback: '=',
//            submitCallback: '=',
//            activeSubmitWatcher: '='
//        },
//        link: link
//    }
//});