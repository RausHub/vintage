﻿# README #

### Purpose ###
Adds Google Map V3 to Terratype

